#include <iostream>

using std::cin, std::cout, std::endl;


